<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
		<div>
			<h1>تم استلام طلب جديد</h1>
			<p>تم استلام طلب جديد وحالته الان قيد التدقيق وسيتم التواصل معكم من قبل ادارة التطبيق لاحقا</p>
			<br/>
			<br/>
			<table border="1" width="100%;">
				<tr>
					<td>الاسم</td>
					<td><?php echo e($name); ?></td>
				</tr>
				<tr>
					<td>البريد الالكتروني</td>
					<td><?php echo e($email); ?></td>
				</tr>
				<tr>
					<td>العنوان </td>
					<td><?php echo e($address); ?></td>
				</tr>
				<tr>
					<td>رقم الطلب </td>
					<td><?php echo e($order_id); ?></td>
				</tr>
			</table>
			<br/>
			<p>رقم التتبع</p>
			<p><?php echo e($tracking_number); ?></p>
		</div>
	</center>
</body>
</html><?php /**PATH /home/almaslcm/public_html/almarid/resources/views/emails/order.blade.php ENDPATH**/ ?>