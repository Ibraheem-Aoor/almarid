<?php $__env->startSection('js'); ?>
    <script>
    $(document).ready(function() {
        $('body').on('change', '.mostion' ,function() {        	
        	// alert(this.value);
        	$(".mostion option").show();
        	$(".mostion option[value=" + this.value + "]").hide();
        	$(this).find("option[value=" + this.value + "]").show();
        	$(this).find("option[value=" + this.value + "]").prop("selected", "selected");          
        });
    });
    </script>

    <?php $latitude = 31.406529; if(!empty(Cache::store('file')->get('settings.map_latitude'))) { $latitude = Cache::store('file')->get('settings.map_latitude'); } ?>
    <?php $longitude = 34.2529956; if(!empty(Cache::store('file')->get('settings.map_longitude'))) { $longitude = Cache::store('file')->get('settings.map_longitude'); } ?>
    <?php $zoom = 10; if(!empty(Cache::store('file')->get('settings.map_latitude')) && !empty(Cache::store('file')->get('settings.map_longitude'))) { $zoom = 18; } ?>
    <script>
        function initMap1() {
            var uluru = {lat: <?php echo (double)$latitude; ?>, lng: <?php echo (double)$longitude; ?> };
            var map = new google.maps.Map(document.getElementById('from_map'), {
                zoom: <?php echo intval($zoom); ?>,
                center: uluru
            });
            google.maps.event.addListener(map, 'click', function( event ){
                $('#map_latitude').val(event.latLng.lat());
                $('#map_longitude').val(event.latLng.lng());
            });
        }
    </script>
    <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDDxpf-cv4oGc2NuaK72f8516se1BRkRt8&callback=initMap1&language=ar">
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <span><?php echo e($data['title']); ?></span>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/'.config('app.prefix','admin'))); ?>"><i class="fa fa-dashboard"></i> الرئيسية</a></li>
                <li class="active"><?php echo e($data['title']); ?></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div style="/*padding: 0 15px;*/">
                        <?php if (\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <strong>نجاح !</strong>
                            <?php echo e(\Session::get('success')); ?>

                        </div>
                        <?php endif ?>
                        <?php if (count($errors)): ?>
                        <div class="alert alert-danger">
                            <strong>خطأ !</strong>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif ?>
                    </div>
                </div>
                <div class="col-xs-12" style="margin-top: 15px;">
                    <div class="panel panel-default">
                        <div class="panel-body form_view">

                            <?php echo e(FORM::open([
                                        'files'=>'true',
                                        'class'=>"formular form-horizontal ls_form",
                                        'role'=>"form",
                                        'method'=>'post',
                                        'url'=>config('app.prefix','admin').'/settings/save'])); ?>


                            <div class="form-body">

                                <?php if(isset($data['settings']) && !empty($data['settings']) && count($data['settings']->toArray()) > 0): ?>
                                    <?php $__currentLoopData = $data['settings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label"><?php echo e($row->name); ?></label>
                                            <div class="col-md-9">
                                                <?php if($row->type == 'image'): ?>
                                                    <input type="file" name="<?php echo e($row->key); ?>"> <?php if(!empty($row->value)): ?> <img src="<?php echo e(asset('uploads/settings/'.$row->value)); ?>" width="80px" alt=""> <?php endif; ?>
                                                <?php else: ?>
                                                    <input type="text" name="<?php echo e($row->key); ?>" value="<?php echo e($row->value); ?>" class="form-control" placeholder="<?php echo e($row->name); ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                

                                
                                    
                                    
                                        
                                    
                                

                                



                                
                                    
                                    
                                        
                                    
                                

                                
                                    
                                    
                                        
                                    
                                

                                
                                    
                                    
                                        
                                    
                                

                                
                                    
                                    
                                        
                                    
                                

                                
                                    
                                    
                                        
                                        
                                    
                                

                                
                                    
                                    
                                        
                                        
                                    
                                

                                
                                
                                    
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                    
                                        
                                            
                                            
                                        
                                    
                                
                                

                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                

                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                

                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                

                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                


                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                                

                                
                                    
                                    
                                        
                                    
                                


                                
                                    
                                    
                                        
                                    
                                    
                                        
                                    
                                


                            </div>

                            <div class="form-actions">

                                <div class="row">

                                    <div class="col-md-offset-3 col-md-9">
                                        <button type="submit" class="btn btn-primary">تعديل</button>
                                    </div>

                                </div>

                            </div>

                            <?php echo e(FORM::close()); ?>


                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/almaslcm/public_html/almarid/resources/views/backend/settings/index.blade.php ENDPATH**/ ?>