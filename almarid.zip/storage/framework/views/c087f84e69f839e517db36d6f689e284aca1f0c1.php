<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/frontend/styles/contact.css')); ?>">
    <style type="text/css" media="screen">
        .inner-home{
            height:280px;
        }
        input,select{
            margin-top: 15px;
        }
        footer input{
            margin-top: 0px;
        }  
        .fillter_ads button{
            margin-top: 15px !important;
        }
        .form_submit_button{
            margin-top: 10px  !important;
            margin-bottom: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
    $(document).ready(function() {
        $('body').on('change', '#province_id' ,function() {
            $('#city_id option').hide();
            $('#city_id option.province_'+this.value).show();            
            $('#city_id option.province_'+this.value+':first').prop("selected", "selected");            
        });
    });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                الرئيسية
                <small>لوحة التحكم</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> الرئيسية</a></li>
                <li class="active">لوحة التحكم</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">



            <!-- Small boxes (Stat box) -->
            <div class="row">

            <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
            <div class="inner">
            <h3><?php echo e($data['cars']); ?></h3>

            <p>عدد السيارات</p>
            </div>
            <div class="icon">
            <i class="fa fa-car"></i>
            </div>
            <a class="small-box-footer"></a>
            </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
            <div class="inner">
            <h3><?php echo e($data['orders']); ?></h3>
            <p>عدد الطلبات</p>
            </div>
            <div class="icon">
            <i class="fa fa-opencart"></i>
            </div>
            <a class="small-box-footer"></a>

            </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
            <div class="inner">
            <h3><?php echo e($data['brands']); ?></h3>
            <p>عدد العلامات التجارية</p>
            </div>
            <div class="icon">
            <i class="fa fa-star"></i>
            </div>
            <a class="small-box-footer"></a>

            </div>
            </div>



                <!-- ./col -->
                <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green">
                <div class="inner">
                <h3><?php echo e($data['models']); ?></h3>
                <p>عدد الموديلات</p>
                </div>
                <div class="icon">
                <i class="fa fa-calendar"></i>
                </div>
                <a class="small-box-footer"></a>

                </div>
                </div>


            </div>





            
                
                    
                    
                    
                    
                
            
            
                
                
                
                
                
                
                
            

                
                    
                        
                        
                        
                            
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                        
                        
                        
                        
                        
                    
                
                
                     
                        
                        
                            
                                
                            
                        
                    
                

                
                    
                        
                        
                            
                                
                            
                        
                    
                


                
                    
                

            
            


            
            

                
                    
                    
                        
                            

                            
                        
                        
                            
                        
                        
                    
                
                
                
                    
                    
                        
                            
                            
                        
                        
                            
                        
                        

                    
                
                
                
                    
                    
                        
                           
                            
                        
                        
                            
                        
                        

                    
                



                
                
                    
                    
                        
                           
                            
                        
                        
                            
                        
                        

                    
                

                 
                    
                    
                        
                            
                            
                        
                        
                            
                        
                         
                    
                
                
            

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/almaslcm/public_html/almarid/resources/views/backend/common/home.blade.php ENDPATH**/ ?>