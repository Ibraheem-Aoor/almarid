<footer class="main-footer">
    <div class="pull-right hidden-xs">
        
        <?php echo e(date('Y-m-d',time())); ?>

    </div>
    <strong> جميع الحقوق محفوظة &copy; </strong>
</footer><?php /**PATH /home/almaslcm/public_html/almarid/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>