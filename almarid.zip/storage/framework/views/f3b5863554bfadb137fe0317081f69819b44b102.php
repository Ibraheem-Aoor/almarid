<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/backend/css/app.css')); ?>" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body dir="rtl">
    <div id="app">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <img src="<?php echo e(asset('assets/frontend/img/logo.png')); ?>" style="margin: 40px 0;height: 150px;">
                </div>
            </div>
        </div>
        
            
                
                

                    
                    
                        
                        
                        
                        
                    

                    
                    
                        
                    
                

                
                    
                    
                        
                    

                    
                    
                        
                        
                            
                            
                        
                            
                                
                                    
                                

                                
                                    
                                        
                                            
                                                     
                                            
                                        

                                        
                                            
                                        
                                    
                                
                            
                        
                    
                
            
        

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/backend/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/almaslcm/public_html/almarid/resources/views/layouts/app.blade.php ENDPATH**/ ?>