<footer class="main-footer">
    <div class="pull-right hidden-xs">
        {{--<b>Date</b> --}}
        {{ date('Y-m-d',time()) }}
    </div>
    <strong> جميع الحقوق محفوظة &copy; </strong>
</footer>