<?php

return [

    /*
    |--------------------------------------------------------------------------
    | authentication language lines
    |--------------------------------------------------------------------------
    |
    | the following language lines are used during authentication for various
    | messages that we need to display to the user. you are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'not_complete' => 'Order Still Pending Yet',

];
